<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../bootstrap/js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.js"></script>
    <script src="../bootstrap/js/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $(function(){
                $("#menu").load("../navbar/navbar.html");
            });
        });
    </script>
    <title>Document</title>
</head>
<body>

<img src="../imagens/Durval_Discos_logo_transparent.png" 
     alt="Logo" 
     style="position: fixed; top: 10px; right: 10px; width: 120px; z-index: 1000;">

<div class="container mt-5">
    <div id='menu'></div>
    <h1>Cadastrar Venda</h1>
    <form action="addVenda.php" method="POST">
        <input class="form-control mb-2" type="date" name="data" placeholder="Data" required><br>
        <select class="form-select mb-2" name="Disco">
            <option value="">Selecione um disco</option>
            <?php
                require_once '../init.php';
                $PDO = db_connect();
                $sql = 'SELECT * FROM disco';
                $stmt = $PDO->prepare($sql);
                $stmt->execute();
                $artistas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($discos as $disco) {
                    echo "<option value='{$disco['idDisco']}'>{$disco['nome_disco']}</option>";
                }
            ?>
        </select>
        <select class="form-select mb-2" name="Cliente">
            <option value="">Selecione um cliente</option>
            <?php
                require_once '../init.php';
                $PDO = db_connect();
                $sql = 'SELECT * FROM venda';
                $stmt = $PDO->prepare($sql);
                $stmt->execute();
                $artistas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($clientes as $cliente) {
                    echo "<option value='{$cliente['idCliente']}'>{$cliente['nome']}</option>";
                }
            ?>
        </select>
        <input class="form-control mb-2" type="submit" value="Cadastrar">
    </form>
</div>
</body>
</html>