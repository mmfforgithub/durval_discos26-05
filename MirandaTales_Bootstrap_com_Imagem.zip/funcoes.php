<?php function formatarData($data) {
     return date('d/m/Y', strtotime($data)); 
    } 
?>

